var content=$(".content-block");
$(".tab .list li").on("click",function(){
  $(this).addClass("active");
  $(this).siblings().removeClass("active");
  var index=$(this).index();
  $(content[index]).addClass("content-active");
  $(content[index]).siblings().removeClass("content-active");
})